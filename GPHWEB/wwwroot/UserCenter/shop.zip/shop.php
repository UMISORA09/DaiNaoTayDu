﻿<!DOCTYPE html>
<?php 
  include_once "../Configuration/config.inc.php";
  if(!$_SESSION['accountName']) exit("<script> alert('请登陆后使用！');location.href='Login.php';</script>");
?> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $WebTitle; ?>-物品商城</title>
<link rel=stylesheet type=text/css href="/ClientRes/Styles/reset.css">

<link href="/ClientRes/Styles/BasicStyle.css?_v=634979371913162195" type="text/css" rel="stylesheet" />
<link href="/ClientRes/Styles/Login.css?_v=634979244165265481" type="text/css" rel="stylesheet" />
<link href="/ClientRes/Styles/jmodal.css?_v=634979244164935253" type="text/css" rel="stylesheet" />
<link href="/ClientRes/Styles/loading.css?_v=634979244165185438" type="text/css" rel="stylesheet" />
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript" charset="UTF-8"></script>
 <!--如果google CDN不正常，就从本地获取JQ库。--> 
<script>!window.jQuery && document.write('<script src="/ClientRes/Scripts/jquery.min.js"><\/script>');</script>
<script src="/ClientRes/Scripts/Ipt.js?_v=634979244161733134" type="text/javascript" charset="UTF-8"></script>
<script src="/ClientRes/Scripts/jmodal.js?_v=634979244161903250" type="text/javascript" charset="UTF-8"></script>
<script src="/ClientRes/Scripts/loading.js?_v=634979244164224791" type="text/javascript" charset="UTF-8"></script>
<script src="/ClientRes/Scripts/Common.js?_v=634979706622125062" type="text/javascript" charset="UTF-8"></script>
<script src="/ClientRes/Scripts/AjaxRequest.js?_v=634979244161282816" type="text/javascript" charset="UTF-8"></script></head>
<?php 
require '../TempLate/PublicTop.html';//引用模板 

?> 
<div class="center clearfix mt10">
        <div class="c_main">
<div id=center class=whitebg>
<div id="lighttip" style="margin-bottom: 10px; font-weight: bold; line-height: 25px;
            padding: 5px; color: rgb(255, 255, 255); background-color: rgb(255, 0, 0);" class="lighttip">
在购买之前，请确认您选择的角色已经下线且包裹有空余位置，否则造成任何损失，概不负责。<BR>小提示：商城物品逐步添加，请大家多提宝贵意见，如果物品不在背包查看仓库！ 
</div>
 <ul class=itemlist>  
 <li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg><a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
              <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a></div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename><B>[★★购买前须注意★★]</B> </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>背包位置要留<B>足够多</B></div>
<div class=itemkucun><B>首先游戏整理背包</B> </div>
  <div class=itemprice><B>购买时必须下线</B></div>  
  <div class=itemkucun><B>购买前看清物品</B></div>
  <div class=itemmark><B>购买前看清购买的属性 </B></div>
  <div class=itembtn style="margin-top:7px;"><a class=viewbutton onclick="javascript:void(0);" href="javascript:void(0);">最后确认购买</a> </div></div></li>
  				
<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>极品经验丹</div>
  <div class=itemkucun><B>每个增加人物两百万经验</B></div>
<div class=itemprice>售价:<B>30000积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组99个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm" value="exppill_004">
  <!--数量-->
  <input type="hidden" id="count" value="99">
  <!--价格-->
  <input type="hidden" id="price" value="30000">
  <!--是否绑定-->
  <input type="hidden" id="bind" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy1()">购买物品</a></div></div>
</li>
	 
</ul>
<br/>
 
<ul class=itemlist>  

<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>十倍收益丹</div>
  <div class=itemkucun><B>杀怪打坐真气收益翻10倍</B></div>
<div class=itemprice>售价:<B>0积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组1个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm2" value="expfold_010">
  <!--数量-->
  <input type="hidden" id="count2" value="1">
  <!--价格-->
  <input type="hidden" id="price2" value="0">
  <!--是否绑定-->
  <input type="hidden" id="bind2" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel2" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel2" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes2" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy2()">购买物品</a></div></div>
</li>
  
<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>青龙令</div>
  <div class=itemkucun><B>用于公会发展</B></div>
<div class=itemprice>售价:<B>0积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组10个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm3" value="lingql">
  <!--数量-->
  <input type="hidden" id="count3" value="10">
  <!--价格-->
  <input type="hidden" id="price3" value="0">
  <!--是否绑定-->
  <input type="hidden" id="bind3" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel3" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel3" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes3" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy3()">购买物品</a></div></div>
</li>

<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>白虎令</div>
  <div class=itemkucun><B>用于公会发展</B></div>
<div class=itemprice>售价:<B>0积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组10个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm4" value="lingbh">
  <!--数量-->
  <input type="hidden" id="count4" value="10">
  <!--价格-->
  <input type="hidden" id="price4" value="0">
  <!--是否绑定-->
  <input type="hidden" id="bind4" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel4" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel4" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes4" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy4()">购买物品</a></div></div>
</li>

<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>朱雀令</div>
  <div class=itemkucun><B>用于公会发展</B></div>
<div class=itemprice>售价:<B>0积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组10个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm5" value="lingzq">
  <!--数量-->
  <input type="hidden" id="count5" value="10">
  <!--价格-->
  <input type="hidden" id="price5" value="0">
  <!--是否绑定-->
  <input type="hidden" id="bind5" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel5" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel5" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes5" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy5()">购买物品</a></div></div>
</li>

<li class=item_shop>
  <div class=itemInfo>
  <div class=itemimg>
  <a class="imgbox" title="1" href="javascript:void(0)" rel="lightbox">
  <img border="0"  src="/items/jyd.png" width=66 height=64/> 
  </a>
  </div>
  <div style="COLOR: #8b8d8e; FONT-WEIGHT: bold" class=itemtypename>[物品] </div>
  <div style="COLOR: #f60; FONT-WEIGHT: bold" class=itemname>玄武令</div>
  <div class=itemkucun><B>用于公会发展</B></div>
<div class=itemprice>售价:<B>0积分</B></div>  
  <div class=itemkucun>状态:<B>永久有效</B> </div>
  <div class=itemmark>单次购买每组10个</div>
  <!--物品代码-->
  <input type="hidden" id="wpdm6" value="lingxw">
  <!--数量-->
  <input type="hidden" id="count6" value="10">
  <!--价格-->
  <input type="hidden" id="price6" value="0">
  <!--是否绑定-->
  <input type="hidden" id="bind6" value="1">
  <!--物品的稀有等级-->
  <input type="hidden" id="rarelevel6" value="4">
  <!--物品等级-->
  <input type="hidden" id="itemlevel6" value="1">
  <!--物品附加属性-->
  <input type="hidden" id="attributes6" value="null">
  <div class=itembtn style="margin-top:10px;"><a class="viewbutton" href="javascript:void(0)" onclick="Buy6()">购买物品</a></div></div>
</li>

</ul>
<br/>

</div>

﻿</div></div>

<?php 
require '../TempLate/PublicButtom.html';//引用模板 
?> 
</html>
